"""
Schedule strategies for liability bricks.
"""

from .mortgage_annuity import ScheduleMortgageAnnuity

__all__ = [
    "ScheduleMortgageAnnuity",
]
